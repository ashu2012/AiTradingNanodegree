

# Regression

## Install packages


```python
import sys
!{sys.executable} -m pip install -r requirements.txt
```

    Collecting statsmodels==0.9.0 (from -r requirements.txt (line 1))
    [?25l  Downloading https://files.pythonhosted.org/packages/85/d1/69ee7e757f657e7f527cbf500ec2d295396e5bcec873cf4eb68962c41024/statsmodels-0.9.0-cp36-cp36m-manylinux1_x86_64.whl (7.4MB)
    [K    100% |████████████████████████████████| 7.4MB 1.8MB/s eta 0:00:01    24% |████████                        | 1.8MB 16.7MB/s eta 0:00:01    42% |█████████████▍                  | 3.1MB 13.1MB/s eta 0:00:01    50% |████████████████▏               | 3.7MB 16.3MB/s eta 0:00:01    59% |███████████████████             | 4.4MB 16.1MB/s eta 0:00:01    68% |██████████████████████          | 5.1MB 16.1MB/s eta 0:00:01    85% |███████████████████████████▍    | 6.3MB 14.3MB/s eta 0:00:01    93% |██████████████████████████████  | 7.0MB 9.9MB/s eta 0:00:01
    [?25hRequirement already satisfied: colour==0.1.5 in /opt/conda/lib/python3.6/site-packages (from -r requirements.txt (line 2)) (0.1.5)
    Collecting numpy==1.14.5 (from -r requirements.txt (line 3))
    [?25l  Downloading https://files.pythonhosted.org/packages/68/1e/116ad560de97694e2d0c1843a7a0075cc9f49e922454d32f49a80eb6f1f2/numpy-1.14.5-cp36-cp36m-manylinux1_x86_64.whl (12.2MB)
    [K    100% |████████████████████████████████| 12.2MB 1.8MB/s eta 0:00:01  6% |██                              | 757kB 24.7MB/s eta 0:00:01    16% |█████▎                          | 2.0MB 17.0MB/s eta 0:00:01    61% |███████████████████▊            | 7.5MB 26.1MB/s eta 0:00:01    80% |█████████████████████████▉      | 9.8MB 9.9MB/s eta 0:00:01    85% |███████████████████████████▎    | 10.4MB 11.4MB/s eta 0:00:01
    [?25hCollecting pandas==0.21.1 (from -r requirements.txt (line 4))
    [?25l  Downloading https://files.pythonhosted.org/packages/3a/e1/6c514df670b887c77838ab856f57783c07e8760f2e3d5939203a39735e0e/pandas-0.21.1-cp36-cp36m-manylinux1_x86_64.whl (26.2MB)
    [K    100% |████████████████████████████████| 26.2MB 675kB/s ta 0:00:011 0% |                                | 51kB 8.1MB/s eta 0:00:04    4% |█▌                              | 1.2MB 13.5MB/s eta 0:00:02    9% |██▉                             | 2.4MB 12.1MB/s eta 0:00:02    11% |███▋                            | 3.0MB 13.1MB/s eta 0:00:02    13% |████▍                           | 3.6MB 16.0MB/s eta 0:00:02    16% |█████▏                          | 4.2MB 11.6MB/s eta 0:00:02    18% |██████                          | 4.9MB 25.6MB/s eta 0:00:01    20% |██████▋                         | 5.5MB 23.4MB/s eta 0:00:01    34% |███████████                     | 8.9MB 12.0MB/s eta 0:00:02    38% |████████████▏                   | 10.0MB 7.7MB/s eta 0:00:03    44% |██████████████                  | 11.6MB 12.1MB/s eta 0:00:02    48% |███████████████▌                | 12.7MB 12.0MB/s eta 0:00:02    58% |██████████████████▉             | 15.4MB 24.2MB/s eta 0:00:01    62% |████████████████████▏           | 16.5MB 12.0MB/s eta 0:00:01    67% |█████████████████████▌          | 17.6MB 13.5MB/s eta 0:00:01    72% |███████████████████████▎        | 19.1MB 8.6MB/s eta 0:00:01    73% |███████████████████████▋        | 19.4MB 23.2MB/s eta 0:00:01    75% |████████████████████████▎       | 19.9MB 8.0MB/s eta 0:00:01    77% |█████████████████████████       | 20.4MB 11.2MB/s eta 0:00:01    79% |█████████████████████████▌      | 20.9MB 13.1MB/s eta 0:00:01    81% |██████████████████████████▏     | 21.5MB 11.0MB/s eta 0:00:01    87% |████████████████████████████    | 23.0MB 21.9MB/s eta 0:00:01    91% |█████████████████████████████▎  | 24.0MB 8.8MB/s eta 0:00:01    93% |██████████████████████████████  | 24.6MB 11.7MB/s eta 0:00:01    99% |████████████████████████████████| 26.2MB 8.0MB/s eta 0:00:01
    [?25hCollecting plotly==2.2.3 (from -r requirements.txt (line 5))
    [?25l  Downloading https://files.pythonhosted.org/packages/99/a6/8214b6564bf4ace9bec8a26e7f89832792be582c042c47c912d3201328a0/plotly-2.2.3.tar.gz (1.1MB)
    [K    100% |████████████████████████████████| 1.1MB 15.0MB/s ta 0:00:01    17% |█████▊                          | 194kB 20.9MB/s eta 0:00:01
    [?25hRequirement already satisfied: scikit-learn==0.19.1 in /opt/conda/lib/python3.6/site-packages (from -r requirements.txt (line 6)) (0.19.1)
    Requirement already satisfied: six==1.11.0 in /opt/conda/lib/python3.6/site-packages (from -r requirements.txt (line 7)) (1.11.0)
    Requirement already satisfied: patsy in /opt/conda/lib/python3.6/site-packages (from statsmodels==0.9.0->-r requirements.txt (line 1)) (0.4.1)
    Requirement already satisfied: pytz>=2011k in /opt/conda/lib/python3.6/site-packages (from pandas==0.21.1->-r requirements.txt (line 4)) (2017.3)
    Requirement already satisfied: python-dateutil>=2 in /opt/conda/lib/python3.6/site-packages (from pandas==0.21.1->-r requirements.txt (line 4)) (2.6.1)
    Requirement already satisfied: decorator>=4.0.6 in /opt/conda/lib/python3.6/site-packages (from plotly==2.2.3->-r requirements.txt (line 5)) (4.0.11)
    Requirement already satisfied: nbformat>=4.2 in /opt/conda/lib/python3.6/site-packages (from plotly==2.2.3->-r requirements.txt (line 5)) (4.4.0)
    Requirement already satisfied: requests in /opt/conda/lib/python3.6/site-packages (from plotly==2.2.3->-r requirements.txt (line 5)) (2.18.4)
    Requirement already satisfied: traitlets>=4.1 in /opt/conda/lib/python3.6/site-packages (from nbformat>=4.2->plotly==2.2.3->-r requirements.txt (line 5)) (4.3.2)
    Requirement already satisfied: jupyter-core in /opt/conda/lib/python3.6/site-packages (from nbformat>=4.2->plotly==2.2.3->-r requirements.txt (line 5)) (4.4.0)
    Requirement already satisfied: jsonschema!=2.5.0,>=2.4 in /opt/conda/lib/python3.6/site-packages (from nbformat>=4.2->plotly==2.2.3->-r requirements.txt (line 5)) (2.6.0)
    Requirement already satisfied: ipython-genutils in /opt/conda/lib/python3.6/site-packages (from nbformat>=4.2->plotly==2.2.3->-r requirements.txt (line 5)) (0.2.0)
    Requirement already satisfied: chardet<3.1.0,>=3.0.2 in /opt/conda/lib/python3.6/site-packages (from requests->plotly==2.2.3->-r requirements.txt (line 5)) (3.0.4)
    Requirement already satisfied: idna<2.7,>=2.5 in /opt/conda/lib/python3.6/site-packages (from requests->plotly==2.2.3->-r requirements.txt (line 5)) (2.6)
    Requirement already satisfied: urllib3<1.23,>=1.21.1 in /opt/conda/lib/python3.6/site-packages (from requests->plotly==2.2.3->-r requirements.txt (line 5)) (1.22)
    Requirement already satisfied: certifi>=2017.4.17 in /opt/conda/lib/python3.6/site-packages (from requests->plotly==2.2.3->-r requirements.txt (line 5)) (2019.11.28)
    Building wheels for collected packages: plotly
      Running setup.py bdist_wheel for plotly ... [?25ldone
    [?25h  Stored in directory: /root/.cache/pip/wheels/98/54/81/dd92d5b0858fac680cd7bdb8800eb26c001dd9f5dc8b1bc0ba
    Successfully built plotly
    [31mtensorflow 1.3.0 requires tensorflow-tensorboard<0.2.0,>=0.1.0, which is not installed.[0m
    Installing collected packages: numpy, pandas, statsmodels, plotly
      Found existing installation: numpy 1.12.1
        Uninstalling numpy-1.12.1:
          Successfully uninstalled numpy-1.12.1
      Found existing installation: pandas 0.23.3
        Uninstalling pandas-0.23.3:
          Successfully uninstalled pandas-0.23.3
      Found existing installation: statsmodels 0.8.0
        Uninstalling statsmodels-0.8.0:
          Successfully uninstalled statsmodels-0.8.0
      Found existing installation: plotly 2.0.15
        Uninstalling plotly-2.0.15:
          Successfully uninstalled plotly-2.0.15
    Successfully installed numpy-1.14.5 pandas-0.21.1 plotly-2.2.3 statsmodels-0.9.0



```python
import pandas as pd
import numpy as np
import os
import helper
import quiz_tests
import matplotlib.pyplot as plt
```


```python
plt.style.use('ggplot')
plt.rcParams['figure.figsize'] = (14, 8)
```

## Simulate two stock prices



```python
# just set the seed for the random number generator
np.random.seed(100)
# use returns to create a price series
drift = 100
r0 = pd.Series(np.random.normal(0, 1, 1000))
s0 = pd.Series(np.cumsum(r0), name='s0') + drift

noise1 = np.random.normal(0, 0.4, 1000)
drift1 = 50
r1 = r0 + noise1
s1 = pd.Series(np.cumsum(r1), name='s1') + drift1

noise2 = np.random.normal(0, 0.4, 1000)
drift2 = 60
r2 = r0 + noise2
s2 = pd.Series(np.cumsum(r2), name='s2') + drift2

pd.concat([s1, s2], axis=1).plot(figsize=(15,6))
plt.show()
```


![png](output_6_0.png)



```python
## Plot data with scatterplot
sc = plt.scatter(s2, s1, s=30, edgecolor='b', alpha=0.7)
plt.xlabel('s2')
plt.ylabel('s1');
```


![png](output_7_0.png)



```python
from sklearn.linear_model import LinearRegression
```

## Quiz: Linear Regression

Note that the LinearRegression().fit() expects 2D numpy arrays.  Since s1 and s2 are pandas series, we can use Series.values to get the values as a numpy array. Since these are 1D arrays, we can use numpy.reshape(-1,1) to make these 1000 row by 1 column 2 dimensional arrays.  

The coefficients of the linear regression, $\beta$ and $intercept$ for the regression line:  
$y = \beta \times x + intercept$  
Can be obtained after fitting to the data.  Use `LinearRegression.coef_` for the slope (beta coefficients) and `LinearRegression.intercept_` for the intercept.  You may want to practice accessing these outside of the function definition, to see if you'll need additional brackets `[]` to access the values.


```python
def regression_slope_and_intercept(xSeries, ySeries):
    """
    xSeries: pandas series, x variable
    ySeries: pandas series, y variable
    """
    lr = LinearRegression()
    #TODO: get the values from each series, reshape to be 2 dimensional
    #set s1 to the x variable, s2 to the y variable
    xVar = np.reshape(xSeries,(-1,1))
    yVar = np.reshape(ySeries,(-1,1))
    
    #TODO: call LinearRegression.fit().  Pass in the x variable then y variable
    lr.fit(xVar,yVar);
    
    #TODO: obtain the slope and intercept
    slope = lr.coef_[0][0]
    intercept = lr.intercept_[0]
    
    
    return (slope, intercept)

quiz_tests.test_regression_slope_and_intercept(regression_slope_and_intercept);
```

    Tests Passed


    /opt/conda/lib/python3.6/site-packages/numpy/core/fromnumeric.py:52: FutureWarning: reshape is deprecated and will raise in a subsequent release. Please use .values.reshape(...) instead
      return getattr(obj, method)(*args, **kwds)



```python
slope, intercept = regression_slope_and_intercept(s1,s2);
print(f"slope {slope:.2f} and intercept {intercept:.2f}")
```

    slope 0.74 and intercept 30.62


    /opt/conda/lib/python3.6/site-packages/numpy/core/fromnumeric.py:52: FutureWarning: reshape is deprecated and will raise in a subsequent release. Please use .values.reshape(...) instead
      return getattr(obj, method)(*args, **kwds)


### Plot the fitted regression line over the scatterplot


```python
plt.scatter(s2, s1, s=30, edgecolor='b', alpha=0.5);
x = np.linspace(s1.min()-5, s1.max()+5, 2)
yPred = slope * x + intercept
plt.plot(yPred,x, alpha=0.2, lw=3, color='r')
plt.xlabel('s2')
plt.ylabel('s1');
```


![png](output_13_0.png)


If you're stuck, you can also check out the solution [here](regression_solution.ipynb)
